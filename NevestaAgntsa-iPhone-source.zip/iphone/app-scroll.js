let cancelActive = () => {};

export function smoothScrollTo(destination) {
    cancelActive();
    const root = document.documentElement;
    const start = window.scrollY;
    const target = Math.max(0, Math.min(destination, root.scrollHeight - window.innerHeight));
    const distance = target - start;
    const previous = root.style.scrollBehavior;
    root.style.scrollBehavior = 'auto';
    const duration = Math.min(1000, Math.max(700, 600 + Math.sqrt(Math.abs(distance)) * 5));
    let frame = 0;
    let started;
    let finished = false;
    const cancel = () => finish(false);
    function finish(completed) {
        if (finished) return;
        finished = true;
        cancelAnimationFrame(frame);
        root.style.scrollBehavior = previous;
        window.removeEventListener('touchstart', cancel);
        window.removeEventListener('wheel', cancel);
        window.removeEventListener('keydown', cancel);
        document.removeEventListener('astro:before-swap', cancel);
        if (cancelActive === cancel) cancelActive = () => {};
        document.dispatchEvent(new CustomEvent('app:scroll-end', {detail: {completed, duration, target}}));
    }
    cancelActive = cancel;
    if (Math.abs(distance) < 1 || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        window.scrollTo({top: target, behavior: 'instant'});
        finish(true);
        return;
    }
    window.addEventListener('touchstart', cancel, {passive: true});
    window.addEventListener('wheel', cancel, {passive: true});
    window.addEventListener('keydown', cancel);
    document.addEventListener('astro:before-swap', cancel, {once: true});
    function tick(now) {
        started ??= now;
        const progress = Math.min(1, (now - started) / duration);
        // Zero velocity and acceleration at both ends, with a smooth middle.
        const eased = progress ** 3 * (progress * (progress * 6 - 15) + 10);
        window.scrollTo({top: start + distance * eased, behavior: 'instant'});
        if (progress < 1) frame = requestAnimationFrame(tick);
        else finish(true);
    }
    frame = requestAnimationFrame(tick);
}
