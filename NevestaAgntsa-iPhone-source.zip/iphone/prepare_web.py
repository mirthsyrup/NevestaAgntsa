from pathlib import Path
import re, shutil, subprocess, urllib.request, hashlib, json
root=Path(__file__).resolve().parent.parent
work=root/'build/web-source'
work.mkdir(parents=True,exist_ok=True)
for name in ['src','public']:
 shutil.copytree(root/name,work/name,dirs_exist_ok=True)
for name in ['package.json','package-lock.json','astro.config.mjs','tailwind.config.mjs']:
 shutil.copy2(root/name,work/name)
shutil.copy2(root/'iphone/app-scroll.js',work/'src/scripts/app-scroll.js')
assets=work/'public/app-assets';assets.mkdir(exist_ok=True)
# Download the site's exact fonts at build time, never on the user's phone.
font_url='https://fonts.googleapis.com/css2?family=Rubik+Bubbles&family=Lora:ital,wght@0,400..700;1,400..700&family=Montserrat:wght@300;400;500;600;700&display=swap'
req=urllib.request.Request(font_url,headers={'User-Agent':'Mozilla/5.0 AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36'})
css=urllib.request.urlopen(req,timeout=60).read().decode()
for url in sorted(set(re.findall(r'https://fonts\.gstatic\.com/[^)\s]+',css))):
 name=hashlib.sha256(url.encode()).hexdigest()[:16]+'.'+url.split('.')[-1]
 (assets/name).write_bytes(urllib.request.urlopen(url,timeout=60).read())
 css=css.replace(url,'/NevestaAgntsa/app-assets/'+name)
(assets/'fonts.css').write_text(css)
feather=urllib.request.urlopen('https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.29.2/feather.min.js',timeout=60).read()
(assets/'feather.min.js').write_bytes(feather)
p=work/'src/layouts/BaseLayout.astro';s=p.read_text()
s=re.sub(r'    <link rel="preconnect"[^\n]+\n','',s)
s=re.sub(r'<link href="https://fonts.googleapis.com/[^\n]+', '<link href={`${import.meta.env.BASE_URL}app-assets/fonts.css`} rel="stylesheet" />',s)
s=s.replace('src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.29.2/feather.min.js"','src={`${import.meta.env.BASE_URL}app-assets/feather.min.js`}')
p.write_text(s)
p=work/'src/styles/global.css'
with p.open('a') as f:
 f.write('''\n/* Full-screen iPhone shell: the background extends beneath system areas. */
#navbar { min-height: calc(64px + env(safe-area-inset-top, 0px)); padding-left: env(safe-area-inset-left, 0px); padding-right: env(safe-area-inset-right, 0px); }
#mobile-menu { padding-left: env(safe-area-inset-left, 0px); padding-right: env(safe-area-inset-right, 0px); }
body { padding-bottom: 0; }
.app-parallax-layer { position: absolute; inset: -64px 0; background-size: cover; background-position: center; background-repeat: no-repeat; pointer-events: none; will-change: transform; }
''')
p=work/'src/pages/index.astro';s=p.read_text().replace('md:bg-fixed ','')
s=s.replace('<script>', "<script>\n    import { smoothScrollTo } from '../scripts/app-scroll.js';", 1)
s=s.replace("target.scrollIntoView({ behavior: 'smooth' });", "smoothScrollTo(window.scrollY + target.getBoundingClientRect().top);")
a=s.index('        const isMobile = () => window.innerWidth <= 768;')
b=s.index('        function handleJoinClick',a)
s=s[:a]+'''        let lastPlay = 0;
        let ticking = false;
        let frame = 0;
        const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
        const layers = [heroEl, parallaxEl].map(el => {
            if (!el) return null;
            const layer = document.createElement('div');
            layer.className = 'app-parallax-layer';
            layer.style.backgroundImage = el.style.backgroundImage;
            el.style.backgroundImage = 'none';
            el.insertBefore(layer, el.firstChild);
            return { el, layer };
        });
        function updateParallax() {
            ticking = false;
            layers.forEach(item => {
                if (!item) return;
                const rect = item.el.getBoundingClientRect();
                const raw = item.el === heroEl ? -rect.top * 0.18 : (rect.top + rect.height / 2 - window.innerHeight / 2) * 0.18;
                const offset = reducedMotion.matches ? 0 : Math.max(-60, Math.min(60, raw));
                item.layer.style.transform = `translate3d(0, ${offset}px, 0)`;
            });
        }
        function onScroll() {
            if (ticking) return;
            ticking = true;
            frame = window.requestAnimationFrame(updateParallax);
        }
        window.addEventListener('scroll', onScroll, { passive: true });
        window.addEventListener('resize', onScroll);
        window.addEventListener('orientationchange', onScroll);
        reducedMotion.addEventListener('change', onScroll);
        onScroll();
        document.addEventListener('astro:before-swap', () => {
            window.cancelAnimationFrame(frame);
            window.removeEventListener('resize', onScroll);
            window.removeEventListener('orientationchange', onScroll);
            reducedMotion.removeEventListener('change', onScroll);
        }, { once: true });

'''+s[b:]
p.write_text(s)
p=work/'src/components/Header.astro';s=p.read_text()
s=s.replace("import { navigate } from 'astro:transitions/client';", "import { smoothScrollTo } from '../scripts/app-scroll.js';")
s=s.replace("window.scrollTo({ top: 0, behavior: 'smooth' });", "smoothScrollTo(0);")
s=s.replace('navigate(import.meta.env.BASE_URL);', 'window.location.assign(import.meta.env.BASE_URL);')
p.write_text(s)
subprocess.run(['npm','ci','--no-audit','--no-fund'],cwd=work,check=True)
subprocess.run(['npm','run','build'],cwd=work,check=True)
out=root/'build/Website/NevestaAgntsa';shutil.copytree(work/'dist',out,dirs_exist_ok=True)
# Every stylesheet, script, font and image needed by the UI must be local.
for html in out.rglob('*.html'):
 text=html.read_text()
 # Local page navigation must not wait for Astro's client transition/preload pipeline.
 text=re.sub(r'<a\b[^>]*>',lambda m: m[0].replace('<a', '<a data-astro-reload', 1) if re.search(r'href=["\']/NevestaAgntsa/',m[0]) else m[0],text)
 html.write_text(text)
 for tag in re.findall(r'<(?:script|link|img)[^>]+>',text):
  if re.search(r'(?:src|href)=["\']https?://',tag) and not any(x in tag for x in ['canonical','og:']):
   raise RuntimeError('External UI dependency: '+tag[:160])
print('OFFLINE website packaged:',len(list(out.rglob('*'))),'entries')
