import json
import re
from pathlib import Path

root = Path(__file__).resolve().parent.parent
source = root / 'src'
if not source.exists():
    source = root / 'reference/src'

def entries(folder):
    result = []
    for path in sorted((source / 'content' / folder).glob('*.md')):
        front, body = path.read_text().split('---', 2)[1:]
        fields = dict(re.findall(r'^([A-Za-z]+):\s*"(.*)"\s*$', front, re.M))
        fields.pop('coverImage', None)
        fields.pop('icon', None)
        fields.update(id=path.stem, body=body.strip())
        result.append(fields)
    return result

about = (source / 'pages/about.astro').read_text().split('<script>')[0]
mission = [' '.join(re.sub('<[^>]+>', '', p).split()) for p in re.findall(r'<p\b[^>]*>(.*?)</p>', about, re.S)]
home = (source / 'pages/index.astro').read_text().split('<script>')[0]
beliefs = []
for title in ['Библия', 'Бог', 'Церковь']:
    match = re.search(r'<h[1-6][^>]*>\s*' + title + r'\s*</h[1-6]>\s*<p[^>]*>(.*?)</p>', home, re.S)
    if match:
        beliefs.append(dict(title=title, body=' '.join(re.sub('<[^>]+>', '', match[1]).split())))
gallery_source = (source / 'pages/gallery.astro').read_text()
gallery = []
for item in re.findall(r'\{\s*id:\s*\d+,[\s\S]*?url:\s*placeholder\d\s*\}', gallery_source):
    gallery.append({
        'id': int(re.search(r'id:\s*(\d+)', item)[1]),
        'title': re.search(r'title:\s*"([^"]+)"', item)[1],
        'description': re.search(r'description:\s*"([^"]+)"', item)[1],
        'categories': json.loads(re.search(r'categories:\s*(\[[^\]]+\])', item)[1]),
        'image': re.search(r'url:\s*(placeholder\d)', item)[1] + '.jpg'
    })
content = dict(mission=mission, beliefs=beliefs, sermons=entries('sermons'), events=entries('events'), gallery=gallery)
assert len(mission) == 2 and len(beliefs) == 3 and len(gallery) == 12
assert all(re.fullmatch(r'[a-f0-9]{32}', s['embedId']) for s in content['sermons'])
destination = Path(__file__).resolve().parent / 'content.json'
destination.write_text(json.dumps(content, ensure_ascii=False, indent=2))
print('Bundled church content:', {k: len(v) for k, v in content.items()})
