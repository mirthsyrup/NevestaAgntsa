#!/bin/bash
set -euo pipefail
device="$(xcrun simctl list devices available -j | python3 -c 'import json,sys; d=json.load(sys.stdin); print(next(x["udid"] for group in d["devices"].values() for x in group if x["name"].startswith("iPhone")))')"
xcrun simctl boot "$device" || true
xcrun simctl bootstatus "$device" -b
xcrun simctl status_bar "$device" override --time '9:41' --dataNetwork wifi --wifiMode active --wifiBars 3 --batteryState charged --batteryLevel 100
xcrun simctl install "$device" build/simulator/NevestaAgntsa.app
xcrun simctl launch "$device" org.nevestaagntsa.iphone
sleep 5
xcrun simctl spawn "$device" launchctl list | grep org.nevestaagntsa.iphone
xcrun simctl io "$device" screenshot build/iPhone-home.png
