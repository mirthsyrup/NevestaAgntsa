#!/bin/bash
set -euo pipefail
device="$(xcrun simctl list devices available -j | python3 -c 'import json,sys; d=json.load(sys.stdin); print(next(x["udid"] for group in d["devices"].values() for x in group if x["name"].startswith("iPhone")))')"
xcrun simctl boot "$device" || true
xcrun simctl bootstatus "$device" -b
xcrun simctl status_bar "$device" override --time '9:41' --dataNetwork wifi --wifiMode active --wifiBars 3 --batteryState charged --batteryLevel 100
xcrun simctl install "$device" build/simulator/NevestaAgntsa.app
xcrun simctl launch "$device" org.nevestaagntsa.iphone --verify-site
container="$(xcrun simctl get_app_container "$device" org.nevestaagntsa.iphone data)"
mkdir -p build/preview
for i in {1..150}; do
    if [[ -f "$container/Documents/verification.txt" || -f "$container/Documents/verification-failed.txt" ]]; then break; fi
    sleep 2
done
cp "$container"/Documents/*.png build/preview/ || true
cp "$container"/Documents/verification*.txt build/preview/ || true
xcrun simctl io "$device" screenshot build/iPhone-home.png
cp build/iPhone-home.png build/preview/iPhone-home.png
xcrun simctl spawn "$device" launchctl list | grep org.nevestaagntsa.iphone
if [[ -f "$container/Documents/verification-failed.txt" ]]; then cat "$container/Documents/verification-failed.txt"; exit 1; fi
cat "$container/Documents/verification.txt"
(cd build/preview && zip -qr ../iPhone-verification.zip .)
