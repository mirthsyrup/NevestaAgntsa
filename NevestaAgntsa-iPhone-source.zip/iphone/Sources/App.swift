import SwiftUI
import UIKit

@main
struct NevestaApp: App {
    var body: some Scene {
        WindowGroup {
            ChurchAppView().preferredColorScheme(.light)
        }
    }
}

enum Page: String, CaseIterable, Identifiable {
    case home = "Главная", about = "О нас", sermons = "Проповеди", events = "События"
    case gallery = "Галерея", contacts = "Контакты", donate = "Пожертвовать"
    var id: String { rawValue }
    var icon: String {
        switch self {
        case .home: return "house"
        case .about: return "person.3"
        case .sermons: return "play.rectangle"
        case .events: return "calendar"
        case .gallery: return "photo.on.rectangle"
        case .contacts: return "location"
        case .donate: return "heart"
        }
    }
}

enum Palette {
    static let paper = Color(red: 0.98, green: 0.97, blue: 0.95)
    static let dark = Color(red: 0.10, green: 0.10, blue: 0.10)
    static let gold = Color(red: 0.65, green: 0.48, blue: 0.36)
    static let lightGold = Color(red: 0.76, green: 0.62, blue: 0.50)
}

struct Sermon: Codable, Identifiable {
    let id: String, title: String, date: String, speaker: String, embedId: String, body: String
}
struct ChurchEvent: Codable, Identifiable {
    let id: String, title: String, day: String, month: String, timeOrDate: String, location: String, body: String
}
struct GalleryItem: Codable, Identifiable {
    let id: Int, title: String, description: String, categories: [String], image: String
}
struct ChurchContent: Codable {
    let mission: [String], beliefs: [Belief], sermons: [Sermon], events: [ChurchEvent], gallery: [GalleryItem]
    struct Belief: Codable, Identifiable {
        let title: String, body: String
        var id: String { title }
    }
    static let bundled: ChurchContent = {
        guard let url = Bundle.main.url(forResource: "content", withExtension: "json"),
              let bytes = try? Data(contentsOf: url),
              let content = try? JSONDecoder().decode(ChurchContent.self, from: bytes) else {
            fatalError("Missing or invalid bundled church content")
        }
        return content
    }()
}

enum ChurchLinks {
    static let site = "https://mirthsyrup.github.io/NevestaAgntsa/"
    static let phone = "tel:+79373864064"
    static let email = "mailto:nevestaagntsa@gmail.com"
    static let map = "https://yandex.ru/maps/?text=56.108023,47.177126"
    static let donate = "https://sberbank.ru/qr/uuid=1000297551"
    static let socials: [(String, String, String)] = [
        ("Rutube", "play.rectangle", "https://rutube.ru/channel/42730775/"),
        ("Telegram", "paperplane", "https://t.me/nevestaagntsa"),
        ("MAX", "bubble.left.and.bubble.right", "https://max.ru/join/M3Dv6oeVwqV-IdYiKvuuUPg8D1X6905NkvuNQjQW4TE")
    ]
}

struct AssetImage: View {
    let name: String
    var body: some View {
        if let url = Bundle.main.url(forResource: name, withExtension: nil, subdirectory: "Media"),
           let image = UIImage(contentsOfFile: url.path) {
            Image(uiImage: image).resizable()
        } else {
            Rectangle().fill(Palette.lightGold.opacity(0.2))
                .overlay(Image(systemName: "photo").foregroundStyle(Palette.gold))
        }
    }
}

struct CrossMark: View {
    var body: some View {
        ZStack {
            Capsule().frame(width: 3, height: 29)
            Capsule().frame(width: 21, height: 3).offset(y: -5)
        }.frame(width: 30, height: 32)
    }
}

struct GlowBackground: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    var body: some View {
        GeometryReader { geometry in
            TimelineView(.animation(minimumInterval: 1.0 / 24.0, paused: reduceMotion || scenePhase != .active)) { timeline in
                let time = reduceMotion ? 0 : timeline.date.timeIntervalSinceReferenceDate
                Canvas { context, size in
                    for i in 0..<6 {
                        let seed = Double(i)
                        let x = size.width * (0.5 + 0.45 * sin(time * 0.035 + seed * 2.1))
                        let y = size.height * (0.5 + 0.45 * cos(time * 0.03 + seed * 1.7))
                        let r = 110.0 + seed * 9
                        let path = Path(ellipseIn: CGRect(x: x-r, y: y-r, width: r*2, height: r*2))
                        context.fill(path, with: .radialGradient(Gradient(colors: [Palette.lightGold.opacity(0.23), .clear]), center: CGPoint(x:x, y:y), startRadius: 0, endRadius: r))
                    }
                }
            }.frame(width: geometry.size.width, height: geometry.size.height)
        }.allowsHitTesting(false).accessibilityHidden(true)
    }
}

struct SectionHeading: View {
    let eyebrow: String
    let title: String
    var body: some View {
        VStack(spacing: 12) {
            Text(eyebrow.uppercased()).font(.caption.weight(.medium)).tracking(3).foregroundStyle(Palette.gold)
            Text(title).font(.system(.largeTitle, design: .serif)).multilineTextAlignment(.center)
            Capsule().fill(Palette.lightGold.opacity(0.6)).frame(width: 48, height: 2)
        }.frame(maxWidth: .infinity).padding(.vertical, 16)
    }
}

struct GoldButton: View {
    let title: String
    let icon: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.subheadline.weight(.semibold)).padding(.horizontal, 25).padding(.vertical, 17)
                .frame(maxWidth: .infinity)
                .foregroundStyle(.white).background(Palette.gold, in: Capsule())
        }.buttonStyle(.plain)
    }
}

struct GlassCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content.padding(22).frame(maxWidth: .infinity, alignment: .leading)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 26))
            .overlay(RoundedRectangle(cornerRadius: 26).stroke(.white.opacity(0.65), lineWidth: 1))
            .shadow(color: Palette.gold.opacity(0.07), radius: 14, y: 6)
    }
}

struct ChurchAppView: View {
    @State private var page: Page = .home
    @State private var menu = false
    @State private var sermon: Sermon?
    @State private var event: ChurchEvent?
    @State private var photo: GalleryItem?
    @State private var search = ""
    @State private var galleryFilter = "all"
    @Environment(\.openURL) private var openURL
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    private let content = ChurchContent.bundled
    private let filters = [("Все", "all"), ("Служения", "ministries"), ("Праздники", "holidays"), ("Домашние группы", "homegroups"), ("Альфа-курс", "alphacourse"), ("Изучение Библии", "biblestudy"), ("Селахи", "selah")]

    var body: some View {
        ZStack {
            Palette.paper.ignoresSafeArea()
            if page != .home { GlowBackground().ignoresSafeArea() }
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(spacing: 0) {
                        Color.clear.frame(height: 1).id("top")
                        if page == .home { home }
                        else { pageContent.padding(.horizontal, 22).padding(.top, 24) }
                        footer.padding(.top, 40)
                    }
                }
                .id(page)
                .safeAreaInset(edge: .top, spacing: 0) {
                    header {
                        if page == .home {
                            withAnimation(reduceMotion ? nil : .easeOut(duration: 0.3)) { proxy.scrollTo("top") }
                        } else { navigate(.home) }
                    }
                }
            }
        }
        .foregroundStyle(Palette.dark)
        .sheet(isPresented: $menu) { menuSheet }
        .sheet(item: $sermon) { sermon in sermonDetail(sermon) }
        .sheet(item: $event) { event in eventDetail(event) }
        .fullScreenCover(item: $photo) { photo in photoDetail(photo) }
    }

    private func navigate(_ destination: Page) {
        page = destination
        menu = false
    }
    private func open(_ address: String) {
        if let url = URL(string: address) { openURL(url) }
    }

    private func header(_ goHome: @escaping () -> Void) -> some View {
        HStack {
            Button(action: goHome) { CrossMark().foregroundStyle(Palette.lightGold).frame(width: 44, height: 44) }
                .accessibilityLabel("На главную")
            Spacer()
            Text("НЕВЕСТА АГНЦА").font(.system(size: 11, weight: .medium)).tracking(2.5).foregroundStyle(.white)
            Spacer()
            Button { menu = true } label: {
                Image(systemName: "line.3.horizontal").font(.title3).foregroundStyle(.white).frame(width:44,height:44)
            }.accessibilityLabel("Открыть меню")
        }.padding(.horizontal, 15).padding(.vertical, 7)
            .background(Palette.dark.opacity(0.96))
    }

    private var menuSheet: some View {
        ZStack {
            Palette.dark.ignoresSafeArea()
            GlowBackground().opacity(0.5)
            ScrollView {
                VStack(spacing: 12) {
                    HStack { Spacer(); Button { menu = false } label: { Image(systemName: "xmark").padding(16) }.accessibilityLabel("Закрыть меню") }
                    CrossMark().foregroundStyle(Palette.lightGold).padding(.bottom, 22)
                    ForEach(Page.allCases) { destination in
                        Button { navigate(destination) } label: {
                            Label(destination.rawValue, systemImage: destination.icon)
                                .font(.title3).padding(14).frame(maxWidth: .infinity)
                                .foregroundStyle(page == destination ? Palette.lightGold : .white)
                        }
                    }
                    Text("Церковь · Чебоксары").font(.caption).foregroundStyle(.white.opacity(0.4)).padding(.top, 24)
                }.padding(24)
            }
        }.foregroundStyle(.white).presentationDragIndicator(.visible)
    }

    private var home: some View {
        VStack(spacing: 36) {
            ZStack(alignment: .bottom) {
                GeometryReader { geometry in
                    AssetImage(name: "hero-bg.jpg").scaledToFill().frame(width: geometry.size.width, height: geometry.size.height).clipped()
                }
                LinearGradient(colors: [.black.opacity(0.25), .black.opacity(0.72)], startPoint: .top, endPoint: .bottom)
                GlowBackground().opacity(0.55)
                VStack(spacing: 22) {
                    Text("ХРИСТИАНСКАЯ ЦЕРКОВЬ").font(.caption.weight(.medium)).tracking(3).foregroundStyle(Palette.lightGold)
                    Text("Невеста\nАгнца").font(.system(size: 54, weight: .regular, design: .serif)).multilineTextAlignment(.center).foregroundStyle(.white)
                    Text("«…пойди, я покажу тебе жену,\nневесту Агнца»").font(.system(.body, design: .serif)).italic().multilineTextAlignment(.center).foregroundStyle(.white.opacity(0.8))
                    Text("Откровение 21:9").font(.caption).foregroundStyle(Palette.lightGold)
                    GoldButton(title: "Присоединиться", icon: "arrow.right") { navigate(.contacts) }
                    Button("Смотреть проповеди") { navigate(.sermons) }.font(.subheadline).foregroundStyle(.white).padding(8)
                }.padding(.horizontal, 32).padding(.vertical, 42)
            }.frame(minHeight: 540)
            VStack(spacing: 24) {
                SectionHeading(eyebrow: "Наша миссия", title: "Свет миру\nи соль земли")
                AssetImage(name: "about-community.jpg").scaledToFill().frame(height: 220).clipped().clipShape(RoundedRectangle(cornerRadius: 26))
                Text(content.mission[0]).font(.body).lineSpacing(7)
                Button("Познакомиться с церковью →") { navigate(.about) }.foregroundStyle(Palette.gold).padding(10)
                SectionHeading(eyebrow: "Служение слова", title: "Проповеди")
                ForEach(content.sermons.prefix(2)) { item in sermonCard(item) }
                GoldButton(title: "Все проповеди", icon: "play.rectangle") { navigate(.sermons) }
                SectionHeading(eyebrow: "Вместе в вере", title: "Время служений")
                schedule
                GoldButton(title: "События церкви", icon: "calendar") { navigate(.events) }
            }.padding(.horizontal, 22)
        }
    }

    @ViewBuilder private var pageContent: some View {
        switch page {
        case .home: EmptyView()
        case .about: aboutPage
        case .sermons: sermonsPage
        case .events: eventsPage
        case .gallery: galleryPage
        case .contacts: contactsPage
        case .donate: donatePage
        }
    }

    private var aboutPage: some View {
        VStack(spacing: 25) {
            SectionHeading(eyebrow: "Познакомьтесь с нами", title: "История и видение церкви")
            AssetImage(name:"about-community.jpg").scaledToFill().frame(height:260).clipped().clipShape(RoundedRectangle(cornerRadius:26))
            ForEach(content.mission, id: \.self) { Text($0).font(.body).lineSpacing(8).frame(maxWidth: .infinity, alignment: .leading) }
            ForEach(content.beliefs) { belief in
                GlassCard { VStack(alignment: .leading, spacing: 12) {
                    Text(belief.title).font(.system(.title2, design: .serif)).foregroundStyle(Palette.gold)
                    Text(belief.body).lineSpacing(6)
                } }
            }
        }
    }

    private var sermonsPage: some View {
        VStack(spacing: 22) {
            SectionHeading(eyebrow: "Служение слова", title: "Проповеди")
            HStack {
                Image(systemName:"magnifyingglass").foregroundStyle(Palette.gold)
                TextField("Название или проповедник", text:$search).textInputAutocapitalization(.never).autocorrectionDisabled()
                    .accessibilityLabel("Поиск проповедей")
            }.padding(16).background(.regularMaterial, in: Capsule())
            let results = content.sermons.filter { search.isEmpty || ($0.title + " " + $0.speaker).localizedCaseInsensitiveContains(search) }
            if results.isEmpty { Text("По этому запросу проповедей нет").foregroundStyle(.secondary).padding() }
            ForEach(results) { sermonCard($0) }
            externalLink("Канал церкви на Rutube", icon:"play.rectangle", url:ChurchLinks.socials[0].2)
        }
    }

    private func sermonCard(_ item: Sermon) -> some View {
        Button { sermon = item } label: {
            VStack(alignment: .leading, spacing: 0) {
                ZStack {
                    AssetImage(name: "sermon-placeholder.jpg").scaledToFill().frame(height: 190).clipped()
                    Circle().fill(.ultraThinMaterial).frame(width:58,height:58).overlay(Image(systemName:"play.fill").foregroundStyle(Palette.gold))
                }
                VStack(alignment:.leading,spacing:10) {
                    Text(item.date).font(.caption).foregroundStyle(Palette.gold)
                    Text(item.title).font(.system(.title2,design:.serif)).foregroundStyle(Palette.dark)
                    if !item.speaker.isEmpty { Text(item.speaker).font(.subheadline).foregroundStyle(.secondary) }
                }.padding(22).frame(maxWidth:.infinity,alignment:.leading)
            }.background(.regularMaterial).clipShape(RoundedRectangle(cornerRadius:26))
        }.buttonStyle(.plain).accessibilityLabel("Проповедь: \(item.title)")
    }

    private func sermonDetail(_ item: Sermon) -> some View {
        DetailSheet(title: item.title) {
            AssetImage(name:"sermon-placeholder.jpg").scaledToFill().frame(height:220).clipped().clipShape(RoundedRectangle(cornerRadius:22))
            Text(item.date + (item.speaker.isEmpty ? "" : " · " + item.speaker)).foregroundStyle(Palette.gold)
            Text(item.body).lineSpacing(7)
            GoldButton(title:"Смотреть на Rutube",icon:"play.fill") { open("https://rutube.ru/video/" + item.embedId + "/") }
        }
    }

    private var eventsPage: some View {
        VStack(spacing:24) {
            SectionHeading(eyebrow:"Календарь",title:"События церкви")
            schedule
            Text("Объявления сайта").font(.system(.title2,design:.serif)).frame(maxWidth:.infinity,alignment:.leading)
            ForEach(content.events) { item in
                Button { event = item } label: {
                    GlassCard {
                        HStack(alignment:.top,spacing:18) {
                            VStack(spacing:3) {
                                Text(item.day).font(.title2.weight(.medium))
                                Text(item.month).font(.caption)
                            }.foregroundStyle(Palette.gold).frame(width:70)
                            VStack(alignment:.leading,spacing:10) {
                                Text(item.title).font(.system(.title3,design:.serif))
                                Text(item.timeOrDate).font(.subheadline).foregroundStyle(.secondary)
                                Label(item.location,systemImage:"mappin").font(.caption).foregroundStyle(Palette.gold)
                            }
                        }
                    }
                }.buttonStyle(.plain)
            }
        }
    }

    private func eventDetail(_ item: ChurchEvent) -> some View {
        DetailSheet(title:item.title) {
            Text(item.day + " " + item.month + " · " + item.timeOrDate).foregroundStyle(Palette.gold)
            Label(item.location,systemImage:"mappin.and.ellipse")
            Text(item.body).lineSpacing(7)
            GoldButton(title:"Уточнить информацию",icon:"phone") { open(ChurchLinks.phone) }
        }
    }

    private var schedule: some View {
        let month = Calendar(identifier:.gregorian).component(.month,from:Date())
        let sundayTime = (6...8).contains(month) ? "17:00" : "10:00"
        return GlassCard {
            VStack(alignment:.leading,spacing:18) {
                Text("Время служений").font(.system(.title2,design:.serif))
                scheduleRow("Воскресенье", "Богослужение", sundayTime)
                Divider()
                scheduleRow("Вторник", "Домашние группы", "18:00")
                Divider()
                scheduleRow("Четверг", "Изучение книги Откровения", "17:30")
                Divider()
                scheduleRow("Пятница", "Молитва за личные нужды", "18:00")
                scheduleRow("Пятница", "Молитвенное собрание", "19:00")
                Text("Летом воскресное служение — в 17:00. Возможны изменения в праздничные дни.").font(.caption).foregroundStyle(.secondary).lineSpacing(4)
            }
        }
    }

    private func scheduleRow(_ day:String, _ name:String, _ time:String) -> some View {
        HStack(alignment:.top,spacing:12) {
            VStack(alignment:.leading,spacing:4) { Text(day).font(.subheadline.weight(.semibold)); Text(name).font(.caption).foregroundStyle(.secondary) }
            Spacer()
            Text(time).font(.system(.body,design:.monospaced)).foregroundStyle(Palette.gold)
        }
    }

    private var galleryPage: some View {
        VStack(spacing:22) {
            SectionHeading(eyebrow:"Жизнь общины",title:"Галерея")
            ScrollView(.horizontal,showsIndicators:false) {
                HStack(spacing:10) {
                    ForEach(filters, id: \.1) { filter in
                        Button(filter.0) { galleryFilter = filter.1 }
                            .font(.subheadline).padding(.horizontal,18).padding(.vertical,12)
                            .foregroundStyle(galleryFilter == filter.1 ? .white : Palette.gold)
                            .background(galleryFilter == filter.1 ? Palette.gold : Palette.gold.opacity(0.08),in:Capsule())
                    }
                }
            }
            ForEach(content.gallery.filter { galleryFilter == "all" || $0.categories.contains(galleryFilter) }) { item in
                Button { photo = item } label: {
                    VStack(alignment:.leading,spacing:12) {
                        AssetImage(name:item.image).scaledToFill().frame(height:230).clipped().clipShape(RoundedRectangle(cornerRadius:24))
                        Text(item.title).font(.system(.title3,design:.serif))
                        Text(item.description).font(.subheadline).foregroundStyle(.secondary)
                    }.frame(maxWidth:.infinity,alignment:.leading)
                }.buttonStyle(.plain).padding(.bottom,12)
            }
        }
    }

    private func photoDetail(_ item:GalleryItem) -> some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing:24) {
                HStack { Spacer(); Button { photo = nil } label: { Image(systemName:"xmark").font(.title3).padding(20) }.accessibilityLabel("Закрыть фотографию") }
                Spacer()
                AssetImage(name:item.image).scaledToFit()
                VStack(spacing:10) { Text(item.title).font(.title3); Text(item.description).font(.subheadline).foregroundStyle(.white.opacity(0.65)) }.padding(22)
                Spacer()
            }
        }.foregroundStyle(.white)
    }

    private var contactsPage: some View {
        VStack(spacing:24) {
            SectionHeading(eyebrow:"Будем рады встрече",title:"Контакты")
            GlassCard {
                VStack(alignment:.leading,spacing:18) {
                    Label("Чебоксары, Чувашская Республика",systemImage:"mappin.and.ellipse").font(.title3)
                    Text("ул. Социалистическая 2г").font(.body)
                    GoldButton(title:"Открыть на карте",icon:"map") { open(ChurchLinks.map) }
                    externalLink("+7 (937) 386-40-64",icon:"phone",url:ChurchLinks.phone)
                    externalLink("nevestaagntsa@gmail.com",icon:"envelope",url:ChurchLinks.email)
                }
            }
            schedule
            GlassCard {
                VStack(alignment:.leading,spacing:12) {
                    Text("Соцсети").font(.system(.title2,design:.serif))
                    ForEach(ChurchLinks.socials,id:\.0) { externalLink($0.0,icon:$0.1,url:$0.2) }
                }
            }
            GlassCard {
                VStack(alignment:.leading,spacing:16) {
                    Text("Документы").font(.system(.title2,design:.serif))
                    Text("Местная религиозная организация христиан веры евангельской пятидесятников «Церковь «Невеста Агнца» г. Чебоксары.\n\nОГРН 1032100003154, ИНН 2129050700.\n\nЗарегистрирована Управлением МНС России по Чувашской Республике 25.06.2003 г.\n\nБланк серии 21 № 000829579, учетный № Минюста РФ 2111010217, выдано 16.01.2015 г.").font(.footnote).lineSpacing(5)
                    externalLink("Политика конфиденциальности",icon:"doc.text",url:ChurchLinks.site + "privacy_policy.pdf")
                    externalLink("Публичная оферта",icon:"doc.text",url:ChurchLinks.site + "public_offer.pdf")
                }
            }
        }
    }

    private var donatePage: some View {
        VStack(spacing:24) {
            SectionHeading(eyebrow:"Материальная помощь",title:"Пожертвование")
            GlassCard {
                VStack(spacing:24) {
                    Text("«Каждый уделяй по расположению сердца, не с огорчением и не с принуждением; ибо доброхотно дающего любит Бог»").font(.system(.title3,design:.serif)).italic().multilineTextAlignment(.center).lineSpacing(5)
                    Text("2 КОРИНФЯНАМ 9:7").font(.caption).tracking(2).foregroundStyle(Palette.gold)
                    Text("Мы благодарны каждому за добровольные пожертвования и десятины. Ваши средства направляются на поддержку церковного служения, содействия нуждающимся и содержание здания.").lineSpacing(6)
                    GoldButton(title:"Пожертвовать онлайн",icon:"heart") { open(ChurchLinks.donate) }
                    AssetImage(name:"qr.png").scaledToFit().frame(width:180,height:180).padding(12).background(.white,in:RoundedRectangle(cornerRadius:18))
                    Text("Перевод через Сбербанк / СБП").font(.caption).foregroundStyle(.secondary)
                    externalLink("Публичная оферта о пожертвовании",icon:"doc.text",url:ChurchLinks.site + "public_offer.pdf")
                }
            }
        }
    }

    private func externalLink(_ title:String,icon:String,url:String) -> some View {
        Button { open(url) } label: {
            HStack(alignment:.center,spacing:12) {
                Image(systemName:icon).frame(width:22)
                Text(title).multilineTextAlignment(.leading)
                Spacer(minLength:0)
                Image(systemName:"arrow.up.right").font(.caption)
            }.font(.subheadline).foregroundStyle(Palette.gold).padding(.vertical,12)
        }.buttonStyle(.plain)
    }

    private var footer: some View {
        VStack(spacing:15) {
            CrossMark().foregroundStyle(Palette.lightGold)
            Text("Невеста Агнца").font(.system(.title2,design:.serif)).foregroundStyle(.white)
            Text("Чебоксары · ул. Социалистическая 2г").font(.caption).foregroundStyle(.white.opacity(0.65))
            Text("© \(String(Calendar.current.component(.year,from:Date()))) МРОХВЕП").font(.caption2).foregroundStyle(.white.opacity(0.4))
        }.frame(maxWidth:.infinity).padding(.vertical,36).background(Palette.dark)
    }
}

struct DetailSheet<Content:View>: View {
    let title:String
    @ViewBuilder var content:Content
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView { VStack(alignment:.leading,spacing:24) {
                Text(title).font(.system(.largeTitle,design:.serif))
                content
            }.padding(24) }
            .background(Palette.paper).foregroundStyle(Palette.dark)
            .toolbar { ToolbarItem(placement:.confirmationAction) { Button("Готово") { dismiss() }.tint(Palette.gold) } }
        }.presentationDragIndicator(.visible)
    }
}
