import UIKit
import WebKit
import SafariServices

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions options: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = SiteController()
        window.makeKeyAndVisible()
        self.window = window
        return true
    }
}

final class SiteController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    static let home = URL(string: "https://mirthsyrup.github.io/NevestaAgntsa/")!
    private(set) var web: WKWebView!
    private let errorPanel = UIStackView()
    private var lastURL = SiteController.home
    private var recoveredProcess = false
    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 22/255, green: 22/255, blue: 22/255, alpha: 1)
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = .all
        web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = self
        web.uiDelegate = self
        web.allowsBackForwardNavigationGestures = true
        web.isOpaque = false
        web.backgroundColor = UIColor(red: 244/255, green: 243/255, blue: 246/255, alpha: 1)
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.scrollView.showsVerticalScrollIndicator = false
        web.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(web)
        NSLayoutConstraint.activate([
            web.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            web.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            web.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            web.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        configureErrorPanel()
        load(Self.home)
        #if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--verify-site") {
            Task { await verifySite() }
        }
        #endif
    }

    private func configureErrorPanel() {
        errorPanel.axis = .vertical
        errorPanel.alignment = .center
        errorPanel.spacing = 20
        errorPanel.backgroundColor = UIColor(red: 244/255, green: 243/255, blue: 246/255, alpha: 1)
        errorPanel.isLayoutMarginsRelativeArrangement = true
        errorPanel.layoutMargins = UIEdgeInsets(top: 32, left: 24, bottom: 32, right: 24)
        let title = UILabel()
        title.text = "Не удалось загрузить сайт"
        title.font = .preferredFont(forTextStyle: .title2)
        title.textColor = .black
        title.numberOfLines = 0
        title.textAlignment = .center
        let message = UILabel()
        message.text = "Проверьте подключение к интернету и попробуйте ещё раз."
        message.font = .preferredFont(forTextStyle: .body)
        message.textColor = .darkGray
        message.numberOfLines = 0
        message.textAlignment = .center
        let retry = UIButton(type: .system)
        retry.setTitle("Повторить", for: .normal)
        retry.addTarget(self, action: #selector(retryLoad), for: .touchUpInside)
        errorPanel.addArrangedSubview(title)
        errorPanel.addArrangedSubview(message)
        errorPanel.addArrangedSubview(retry)
        errorPanel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(errorPanel)
        NSLayoutConstraint.activate([
            errorPanel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            errorPanel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            errorPanel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
        errorPanel.isHidden = true
    }

    private func load(_ url: URL) {
        errorPanel.isHidden = true
        lastURL = url
        web.load(URLRequest(url: url, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 30))
    }
    @objc private func retryLoad() { recoveredProcess = false; load(lastURL) }
    private func isInternal(_ url: URL) -> Bool {
        url.scheme == "https" && url.host == Self.home.host &&
        (url.path == "/NevestaAgntsa" || url.path.hasPrefix("/NevestaAgntsa/"))
    }
    private func openExternal(_ url: URL) {
        guard presentedViewController == nil else { return }
        if ["https", "http"].contains(url.scheme ?? "") {
            let browser = SFSafariViewController(url: url)
            present(browser, animated: true)
        } else if ["tel", "mailto", "sms", "tg", "maps"].contains(url.scheme ?? "") {
            UIApplication.shared.open(url)
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { decisionHandler(.cancel); return }
        let mainFrame = action.targetFrame?.isMainFrame ?? true
        if !mainFrame { decisionHandler(.allow); return } // Embedded players remain embedded.
        if isInternal(url) && url.pathExtension.lowercased() != "pdf" {
            decisionHandler(.allow)
        } else {
            decisionHandler(.cancel)
            openExternal(url)
        }
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if action.targetFrame == nil, let url = action.request.url {
            if isInternal(url) { load(url) } else { openExternal(url) }
        }
        return nil
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        errorPanel.isHidden = true
        recoveredProcess = false
        if let url = webView.url, isInternal(url) { lastURL = url }
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { show(error) }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { show(error) }
    private func show(_ error: Error) {
        guard (error as NSError).code != NSURLErrorCancelled else { return }
        errorPanel.isHidden = false
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        if !recoveredProcess { recoveredProcess = true; load(lastURL) }
        else { errorPanel.isHidden = false }
    }
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Отмена", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        let alert = UIAlertController(title: nil, message: prompt, preferredStyle: .alert)
        alert.addTextField { $0.text = defaultText }
        alert.addAction(UIAlertAction(title: "Отмена", style: .cancel) { _ in completionHandler(nil) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(alert.textFields?.first?.text) })
        present(alert, animated: true)
    }
}

#if targetEnvironment(simulator)
// Test-only code: absent from the device IPA. It observes the actual hosted site,
// exercises its controls, and records WKWebView snapshots without changing CSS.
extension SiteController {
    private func pause(_ seconds: Double) async { try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000)) }
    private func js(_ script: String) async throws -> Any { try await web.evaluateJavaScript(script) }
    private func require(_ script: String, _ name: String) async throws {
        let result = try await js(script)
        if (result as? Bool) != true { throw NSError(domain: "SiteVerification", code: 1, userInfo: [NSLocalizedDescriptionKey: name]) }
    }
    private func snapshot(_ name: String, directory: URL) async throws {
        let image = try await web.takeSnapshot(configuration: nil)
        guard let data = image.pngData() else { throw NSError(domain: "Snapshot", code: 1) }
        try data.write(to: directory.appendingPathComponent(name + ".png"))
    }
    private func verifySite() async {
        let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        var checks = [String]()
        do {
            for route in ["", "about", "sermons", "events", "gallery", "contacts", "donate"] {
                let target = Self.home.appendingPathComponent(route)
                load(target)
                var ready = false
                for _ in 0..<45 {
                    await pause(1)
                    let state = try? await js("document.readyState === 'complete' && !!document.querySelector('h1') && location.pathname.replace(/\\/$/, '') === '/\(target.path.trimmingCharacters(in: CharacterSet(charactersIn: "/")))'")
                    if (state as? Bool) == true { ready = true; break }
                }
                guard ready else { throw NSError(domain: "Load", code: 1, userInfo: [NSLocalizedDescriptionKey: "Page did not load: \(route)"]) }
                await pause(6) // Original curtain and entrance animations finish.
                try await require("document.fonts.status === 'loaded' && document.fonts.check('16px Montserrat') && document.fonts.check('16px Lora')", "Original fonts unavailable: \(route)")
                try await require("document.documentElement.scrollWidth <= innerWidth + 1", "Horizontal overflow: \(route)")
                let pageName = route.isEmpty ? "home" : route
                try await snapshot(pageName, directory: directory)
                checks.append("PASS page \(pageName), fonts, viewport")
                if route.isEmpty {
                    try await require("document.fonts.check('16px \"Rubik Bubbles\"') && getComputedStyle(document.querySelector('h1')).fontFamily.includes('Rubik Bubbles')", "Logo font")
                    _ = try await js("document.querySelector('#nav-toggle').click(); true")
                    await pause(0.5)
                    try await require("document.querySelector('#mobile-menu').classList.contains('menu-visible')", "Menu did not open")
                    try await snapshot("menu", directory: directory)
                    _ = try await js("document.querySelector('#nav-toggle').click(); true")
                    checks.append("PASS original menu opens/closes and logo font")
                }
                if route == "events" {
                    try await require("document.querySelector('#cal-grid').children.length > 0", "Calendar empty")
                    _ = try await js("window.__beforeCalendar = document.querySelector('#cal-grid').innerHTML; document.querySelector('#cal-next-btn').click(); true")
                    try await require("document.querySelector('#cal-grid').innerHTML !== window.__beforeCalendar", "Calendar navigation failed")
                    checks.append("PASS calendar advances")
                }
                if route == "gallery" {
                    _ = try await js("document.querySelector('[data-filter]:not([data-filter=all])').click(); true")
                    await pause(0.6)
                    try await require("Array.from(document.querySelectorAll('[data-categories]')).some(e=>e.style.display==='none')", "Gallery filter failed")
                    checks.append("PASS gallery filter")
                }
            }
            load(Self.home)
            await pause(12)
            try checks.joined(separator: "\n").write(to: directory.appendingPathComponent("verification.txt"), atomically: true, encoding: .utf8)
        } catch {
            try? (checks.joined(separator: "\n") + "\nFAIL " + error.localizedDescription).write(to: directory.appendingPathComponent("verification-failed.txt"), atomically: true, encoding: .utf8)
        }
    }
}
#endif
