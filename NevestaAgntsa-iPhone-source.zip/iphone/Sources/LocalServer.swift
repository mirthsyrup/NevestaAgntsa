import Foundation
import Network

final class LocalServer {
    static let port: UInt16 = 17853
    private var listener: NWListener?
    private let queue = DispatchQueue(label: "org.nevestaagntsa.local-files")
    private let root: URL
    init(root: URL) { self.root = root }
    func start(ready: @escaping (Bool) -> Void) {
        do {
            let params = NWParameters.tcp
            params.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: NWEndpoint.Port(rawValue: Self.port)!)
            let listener = try NWListener(using: params)
            self.listener = listener
            var signaled = false
            listener.stateUpdateHandler = { state in
                switch state {
                case .ready: if !signaled { signaled = true; DispatchQueue.main.async { ready(true) } }
                case .failed: if !signaled { signaled = true; DispatchQueue.main.async { ready(false) } }
                default: break
                }
            }
            listener.newConnectionHandler = { [weak self] connection in
                connection.start(queue: self?.queue ?? DispatchQueue.global())
                self?.receive(connection, bytes: Data())
            }
            listener.start(queue: queue)
        } catch { ready(false) }
    }
    private func receive(_ connection: NWConnection, bytes: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] data, _, complete, error in
            var request = bytes
            if let data = data { request.append(data) }
            if request.range(of: Data("\r\n\r\n".utf8)) != nil { self?.respond(connection, request) }
            else if error != nil || complete || request.count > 65536 { connection.cancel() }
            else { self?.receive(connection, bytes: request) }
        }
    }
    private func respond(_ connection: NWConnection, _ request: Data) {
        guard let text = String(data: request, encoding: .utf8), let line = text.components(separatedBy: "\r\n").first else { connection.cancel(); return }
        let parts = line.split(separator: " ")
        guard parts.count >= 2, parts[0] == "GET" || parts[0] == "HEAD" else { send(connection, status: "405 Method Not Allowed", mime: "text/plain", data: Data()); return }
        let path = String(parts[1]).components(separatedBy: "?")[0].removingPercentEncoding ?? ""
        guard path.hasPrefix("/"), !path.split(separator: "/").contains(".."), !path.contains("\0") else { connection.cancel(); return }
        var file = root.appendingPathComponent(String(path.dropFirst()))
        var directory: ObjCBool = false
        if FileManager.default.fileExists(atPath: file.path, isDirectory: &directory), directory.boolValue { file.appendPathComponent("index.html") }
        if !FileManager.default.fileExists(atPath: file.path), file.pathExtension.isEmpty { file.appendPathComponent("index.html") }
        guard let data = try? Data(contentsOf: file) else { send(connection, status: "404 Not Found", mime: "text/plain", data: Data("Not found".utf8)); return }
        let types = ["html":"text/html; charset=utf-8", "css":"text/css; charset=utf-8", "js":"application/javascript", "mjs":"application/javascript", "json":"application/json", "woff2":"font/woff2", "woff":"font/woff", "ttf":"font/ttf", "png":"image/png", "jpg":"image/jpeg", "jpeg":"image/jpeg", "webp":"image/webp", "svg":"image/svg+xml", "mp4":"video/mp4", "pdf":"application/pdf", "ico":"image/x-icon"]
        let mime = types[file.pathExtension.lowercased()] ?? "application/octet-stream"
        if let rangeLine = text.components(separatedBy: "\r\n").first(where: { $0.lowercased().hasPrefix("range: bytes=") }) {
            let values = rangeLine.components(separatedBy: "=").last!.split(separator: "-", omittingEmptySubsequences: false)
            if values.count == 2, let start = Int(values[0]), start >= 0, start < data.count {
                let end = min(Int(values[1]) ?? (data.count-1), data.count-1)
                if end >= start { send(connection, status: "206 Partial Content", mime: mime, data: data.subdata(in: start..<(end+1)), extra: "Content-Range: bytes \(start)-\(end)/\(data.count)\r\n", head: parts[0] == "HEAD"); return }
            }
        }
        send(connection, status: "200 OK", mime: mime, data: data, head: parts[0] == "HEAD")
    }
    private func send(_ connection: NWConnection, status: String, mime: String, data: Data, extra: String = "", head: Bool = false) {
        var reply = Data("HTTP/1.1 \(status)\r\nContent-Type: \(mime)\r\nContent-Length: \(data.count)\r\nAccept-Ranges: bytes\r\nCache-Control: no-cache\r\nConnection: close\r\n\(extra)\r\n".utf8)
        if !head { reply.append(data) }
        connection.send(content: reply, completion: .contentProcessed { _ in connection.cancel() })
    }
    deinit { listener?.cancel() }
}
