#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 iphone/make_content.py
mode="${1:-device}"
if [[ "$mode" == simulator ]]; then
    sdk=iphonesimulator
    target=arm64-apple-ios16.0-simulator
    output=build/simulator/NevestaAgntsa.app
else
    sdk=iphoneos
    target=arm64-apple-ios16.0
    output=build/Payload/NevestaAgntsa.app
fi
mkdir -p "$output/Media"
cp iphone/Info.plist "$output/Info.plist"
cp iphone/content.json "$output/content.json"
cp src/assets/images/* "$output/Media/"
cp src/assets/gallery/* "$output/Media/"
cp src/assets/sermons/* "$output/Media/"
sips -z 120 120 public/apple-touch-icon.png --out "$output/AppIcon60x60@2x.png" >/dev/null
sips -z 180 180 public/apple-touch-icon.png --out "$output/AppIcon60x60@3x.png" >/dev/null
sdk_path="$(xcrun --sdk "$sdk" --show-sdk-path)"
xcrun --sdk "$sdk" swiftc -parse-as-library -O -whole-module-optimization \
    -sdk "$sdk_path" -target "$target" -module-name NevestaAgntsa \
    -framework SwiftUI -framework UIKit \
    -Xlinker -rpath -Xlinker @executable_path/Frameworks \
    iphone/Sources/*.swift -o "$output/NevestaAgntsa"
plutil -lint "$output/Info.plist"
if [[ "$mode" == simulator ]]; then
    codesign --force --sign - "$output"
else
    # Ad-hoc signature is replaced by the user's IPA signing service.
    codesign --force --sign - "$output"
    (cd build && zip -qr NevestaAgntsa-iPhone.ipa Payload)
    python3 - <<'PY'
import json, plistlib, zipfile
with zipfile.ZipFile('build/NevestaAgntsa-iPhone.ipa') as ipa:
    info = plistlib.loads(ipa.read('Payload/NevestaAgntsa.app/Info.plist'))
    assert info['CFBundleIdentifier'] == 'org.nevestaagntsa.iphone'
    assert info['UIDeviceFamily'] == [1]
    assert len(ipa.read('Payload/NevestaAgntsa.app/NevestaAgntsa')) > 10000
    data = json.loads(ipa.read('Payload/NevestaAgntsa.app/content.json'))
    for key in ['mission', 'beliefs', 'sermons', 'events', 'gallery']:
        assert data[key], key
    print('IPA package verified:', info['CFBundleDisplayName'])
PY
fi
